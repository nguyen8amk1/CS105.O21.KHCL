# Running the Program

### Bước 1:
Chạy lệnh bên dưới để chương trình hoạt động bình thường:

```bash
python3 -m http.server
```
### Bước 2:
Vào đường dẫn http://localhost:8000 để sử dụng chương trình
